# DevPilot AI

**Understand. Debug. Test. Secure. Ship.**

An evidence-first AI software engineering workspace for exploring repositories, asking code questions with citations, reviewing potential risks, and drafting tests, documentation, and implementation plans.

## Problem

Developers spend time onboarding into unfamiliar code, tracing behavior across files, and translating issues into testable changes. An answer without a source citation is hard to trust, and a generic chatbot does not cover the engineering workflow around that answer.

## Solution

DevPilot analyzes a GitHub repository or ZIP upload, builds a local metadata and line index, and presents repository context plus reviewable engineering outputs in a developer dashboard. A bundled fictional sample makes Demo Mode work without GitHub credentials or an LLM key.

## Key features

- Repository overview, language/framework detection, file tree, entry points, API route hints, and architecture summary.
- GitHub HTTPS archive import and ZIP upload with limits and safe extraction checks.
- Repository chat with retrieved file and line citations; optional IBM watsonx.ai, Gemini, or Ollama adapters.
- Potential security and code-quality findings with source evidence and suggested mitigations.
- Draft implementation plans, test templates, documentation previews, and diff reviews.
- Issue-to-verified-fix workflow with evidence, plan, patch preview, explicit verification approval, before/after regression test, and final review.
- Measured retrieval benchmark with labeled demo cases and file, symbol, and citation validity metrics.
- Optional GitHub issue and pull request lists using server-side credentials.
- SQLite activity and chat persistence; no repo modifications are applied.
- Responsive dark dashboard, Docker support, API docs, and a repeatable demo flow.

## Architecture

See [docs/architecture.md](docs/architecture.md) for the full system and trust boundaries.

## AI agent architecture

The small orchestrator dispatches to repository retrieval, planning, and test-generation specialists. Deterministic checks perform local static scans and diff heuristics. The model provider adapter is optional; retrieved excerpts are passed to a configured provider, while no-key mode clearly says it is using deterministic retrieval. This MVP avoids pretending static findings are model findings or claiming automatic code changes.

## RAG pipeline

Repository files → ignore generated/binary/oversized content → extract metadata and line snippets → lexical scoring → relevant excerpts with `file_path` and `line` → provider prompt or labeled local retrieval answer. The first version uses no external vector database or embedding model, keeping setup light and fallback reliable. The retrieval interface can later be backed by Chroma or FAISS.

## Technology stack

- Frontend: React, TypeScript, Vite, Lucide icons, responsive CSS.
- Backend: Python 3.11+, FastAPI, Pydantic, Uvicorn, httpx.
- Storage: SQLite and local repository files.
- Optional inference: IBM watsonx.ai, Gemini, Ollama. Default: mock/deterministic retrieval.
- Deployment: Docker Compose; API can run on a Python container host and static frontend on Vercel or another static host.

## How IBM Bob 2.0 was used

Record actual Bob IDE tasks here during project development: planning, codebase exploration, feature implementation, debugging, refactoring, tests, documentation, and Git review. Add Bob task session exports/screenshots to `bob_sessions/` if the current event instructions require them. Do not claim steps until a team member has performed them and retained evidence. This README template intentionally does not claim Bob was used by this coding session.

The product represents AI-assisted engineering by grounding repository questions in source evidence and connecting understanding to plans, checks, test drafts, and docs, while keeping outputs reviewable by developers.

## Installation

Requirements: Python 3.11+, Node.js 20+, npm. Docker is optional.

### Backend

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item ..\.env.example ..\.env
$env:PYTHONPATH = (Get-Location).Path
uvicorn app.main:app --reload --env-file ..\.env
```

### Frontend

In a second terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open <http://localhost:5173>. API documentation is at <http://localhost:8000/docs>.

## Environment variables

Copy `.env.example` to `.env` to configure providers or GitHub. The app runs in demo mode with mock provider defaults even when `.env` is absent. Set `LLM_PROVIDER=ibm` with `IBM_API_KEY` and `IBM_PROJECT_ID`, `gemini` with `GEMINI_API_KEY`, or `ollama` with a running Ollama server. `GITHUB_TOKEN` and `GITHUB_REPOSITORY=owner/repo` are only needed for private repository and issue/PR reads. Secrets stay on the backend.

## Demo Mode

1. Start the API and frontend.
2. Click **Try Demo**.
3. Explore the bundled fictional Northstar Tasks repository.
4. Ask “How does account lookup work?” and inspect file/line citations.
5. Open Security and Code Analysis; findings are heuristic potential issues, not a security certification.
6. Generate a plan for “Add OAuth authentication,” a test draft, and docs preview.
7. No configured model key is required. The UI labels local retrieval mode.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health and configured mode |
| POST | `/api/repositories/demo` | Load bundled sample repo |
| POST | `/api/repositories/analyze` | Fetch and analyze a public GitHub repo |
| POST | `/api/repositories/upload` | Analyze ZIP upload |
| GET | `/api/repositories/{id}` | Repository metadata and current findings |
| POST | `/api/chat` | Repository-grounded question |
| POST | `/api/analyze/bugs` | Potential bug/runtime findings |
| POST | `/api/analyze/security` | Potential security findings |
| POST | `/api/generate/tests` | Test draft preview |
| POST | `/api/generate/docs` | Documentation preview |
| POST | `/api/generate/plan` | Requirement-to-plan draft |
| POST | `/api/review` | Diff heuristics and test suggestions |
| GET | `/api/issues` | GitHub open issues when configured |
| GET | `/api/pull-requests` | GitHub open PRs when configured |
| GET | `/api/activity` | Recent local activity |
| POST | `/api/workflow/investigate` | Start issue investigation from a demo or supplied issue |
| POST | `/api/workflow/{id}/plan`, `/patch`, `/test` | Generate a plan, patch preview, and regression test |
| POST | `/api/workflow/{id}/approve`, `/verify`, `/review` | Approve isolated verification, compare before/after, and summarize review |
| GET | `/api/evaluation/run` | Run labeled retrieval benchmark against bundled demo |

## Deployment

### Live demo

- Frontend: _Add the verified Vercel URL after deployment._
- Backend: _Add the verified Render URL after deployment._
- API docs: _Add the Render `/docs` URL after deployment._

No live hosting URL is claimed until both services are deployed and checked.

### Vercel frontend

Create a Vercel project from this GitHub repository and set **Root Directory** to `frontend`. Use the included `frontend/vercel.json` settings: install `npm install`, build `npm run build`, output `dist`. Add the public environment variable `VITE_API_BASE_URL=https://<your-render-service>.onrender.com` in the Vercel project settings for Production (and Preview if needed), then redeploy. The shared API module strips trailing slashes and prefixes each `/api/...` request once. Keep provider and GitHub credentials out of all `VITE_*` variables.

The app uses in-page navigation and has no client-side URL routes; the Vercel rewrite keeps the SPA entry point available on refresh.

### Render backend

The root `render.yaml` defines a free Python web service. Render should use the repository root, install `backend/requirements.txt`, start `backend.app.main:app` on `0.0.0.0:$PORT`, and check `/api/health`. Set `FRONTEND_URL` to the verified Vercel origin in the Render dashboard. The API also permits the two local Vite origins for development. CORS uses an explicit allowlist and does not use `*`.

Optional IBM, Gemini, or GitHub credentials belong in the Render dashboard environment settings only. `.env` is ignored by Git; `.env.example` contains blank placeholders. Demo Mode and the deterministic sample repository work without any external API credentials. GitHub lists gracefully report when their optional server-side token is absent.

### Local development

Copy `.env.example` to `.env` only if configuring backend options. From the repository root, start the API with `python -m uvicorn backend.app.main:app --reload --host 0.0.0.0 --port 8000`; in another terminal, run `cd frontend`, `npm install`, then `npm run dev`. The Vite development proxy sends `/api` to `http://127.0.0.1:8000`. For a direct frontend-to-API request, set `VITE_API_BASE_URL` in the frontend environment.

### Storage on Render Free

The app uses SQLite and the local filesystem for single-user workflow and imported-repository state. The Render configuration places that state under `/tmp`, and Render Free filesystems are ephemeral: database rows, uploaded repositories, activity, and workflow history can disappear when the service restarts or redeploys. The bundled demo repository and benchmark are part of the deployed source and remain available. Use managed PostgreSQL and persistent/object storage before relying on user data in production. Render Free services can spin down after 15 minutes idle and cold starts may take about a minute; the frontend shows a startup state and retries safe GET requests up to three times ([Render Free limits](https://render.com/docs/free)). Vercel Hobby is free for personal, non-commercial use, so confirm that your hackathon use fits its current terms ([Vercel Hobby plan](https://vercel.com/docs/plans/hobby)).

### Docker

Docker remains optional for Vercel/Render. For local container use, run `docker compose up --build`; Compose stores the local database and imported repository files in named volumes.

## GitHub workflow

This project is rooted at the repository root and uses the configured remote `https://github.com/HARIScyber/devpilot.ai.git`. Deployment changes should be committed to `main` only after reviewing `git status` and the diff. Never add `.env`, runtime databases, credentials, `node_modules`, or build output.

## Limitations

- Static checks are narrow heuristic rules; they are not a full SAST engine and can miss or misclassify issues.
- Retrieval is lexical rather than vector-semantic. Citation lines point to matched indexed chunks, not a complete semantic proof. The benchmark measures labeled retrieval only, not answer correctness.
- The issue workflow patch and before/after verifier currently support one bundled demo regression issue only. Imported repositories get investigation evidence, but no automatic patch or test execution.
- The demo verifier runs a bundled trusted fixture in a temporary directory with a timeout; it is not a general hostile-code sandbox.
- GitHub list integration requires an explicitly configured `GITHUB_REPOSITORY`; OAuth, branch writes, PR creation, and automatic fixes are not included.
- Provider API shapes, model availability, and account permissions vary; model calls have graceful retrieval fallback.
- SQLite/local files suit a single-user demo; production needs managed storage, auth, job queueing, rate limits, and stronger isolation.
- Screenshots, deployment URL, Bob session exports, and pitch deck remain to be added by the team after actual work and deployment.

## Next improvements

Add AST-aware cross-language parsing, configurable scope filters, semantic embeddings, background indexing jobs, real coverage/test execution in a sandbox, supported package advisory checks, GitHub webhook/PR integration, authentication, and evaluation against labeled repositories.

## Demo script and submission

See [docs/demo-script.md](docs/demo-script.md) and [docs/hackathon-submission.md](docs/hackathon-submission.md).
